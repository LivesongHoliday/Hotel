define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'reservations/index' + location.search,
                    add_url: 'reservations/add',
                    edit_url: 'reservations/edit',
                    del_url: 'reservations/del',
                    multi_url: 'reservations/multi',
                    import_url: 'reservations/import',
                    table: 'reservations',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'member_id', title: __('Member_id')},
                        {field: 'room_id', title: __('Room_id')},
                        {field: 'reservation_status', title: __('Reservation_status'), searchList: {"new":__('New'),"confirmed":__('Confirmed'),"cancelled":__('Cancelled')}, formatter: Table.api.formatter.status},
                        {field: 'check_in_date', title: __('Check_in_date'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'check_out_date', title: __('Check_out_date'), operate:'RANGE', addclass:'datetimerange', autocomplete:false},
                        {field: 'include_parking', title: __('Include_parking')},
                        {field: 'include_meals', title: __('Include_meals')},
                        {field: 'pet_friendly', title: __('Pet_friendly')},
                        {field: 'created_at', title: __('Created_at')},
                        {field: 'updated_at', title: __('Updated_at')},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
