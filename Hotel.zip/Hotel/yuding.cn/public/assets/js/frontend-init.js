define(['frontend'], function (Frontend) {

});