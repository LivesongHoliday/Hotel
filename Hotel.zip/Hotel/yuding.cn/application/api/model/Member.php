<?php

namespace app\api\model;

use think\Model;

class Member extends Model{

	protected $name = 'member';
	
	
	
}