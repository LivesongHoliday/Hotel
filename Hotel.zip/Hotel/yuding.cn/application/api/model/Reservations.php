<?php

namespace app\api\model;

use think\Model;

class Reservations extends Model{

	protected $name = 'reservations';
	
	
	
}