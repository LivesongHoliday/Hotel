<?php

namespace app\admin\model;

use think\Model;


class Reservations extends Model
{

    

    

    // 表名
    protected $name = 'reservations';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'reservation_status_text'
    ];
    

    
    public function getReservationStatusList()
    {
        return ['new' => __('New'), 'confirmed' => __('Confirmed'), 'cancelled' => __('Cancelled')];
    }


    public function getReservationStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['reservation_status']) ? $data['reservation_status'] : '');
        $list = $this->getReservationStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
