<?php 
 return array (
  'table_name' => 'fa_buiapi_field,fa_buiapi_table',
  'self_path' => '',
  'update_data' => '',
);